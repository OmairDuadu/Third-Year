package com.omair.touristapp.Models;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class Country {
    private long id;
    private String name;
    private String anthomUrl;
    private Bitmap image;
    private ArrayList<City> cityArrayList;

    public Country() {
    }

    public Country(String name, String anthomUrl) {
        this.name = name;
        this.anthomUrl = anthomUrl;
    }

    public Country(long id, String name, String anthomUrl) {
        this.id = id;
        this.name = name;
        this.anthomUrl = anthomUrl;
    }

    public Country(String name, String anthomUrl, Bitmap image) {
        this.name = name;
        this.anthomUrl = anthomUrl;
        this.image = image;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAnthomUrl() {
        return anthomUrl;
    }

    public void setAnthomUrl(String anthomUrl) {
        this.anthomUrl = anthomUrl;
    }

    public ArrayList<City> getCityArrayList() {
        return cityArrayList;
    }

    public void setCityArrayList(ArrayList<City> cityArrayList) {
        this.cityArrayList = cityArrayList;
    }

    public Bitmap getImage() {
        return image;
    }

    public void setImage(Bitmap image) {
        this.image = image;
    }

    public byte[] convertImageToBytes() {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        getImage().compress(Bitmap.CompressFormat.JPEG, 100, stream);
        return stream.toByteArray();
    }


    public void convertBytesToBitmap(byte[] image) {
        ByteArrayInputStream imageStream = new ByteArrayInputStream(image);
        Bitmap theImage = BitmapFactory.decodeStream(imageStream);
        setImage(theImage);
    }


    @Override
    public String toString() {
        return getName();
    }
}
