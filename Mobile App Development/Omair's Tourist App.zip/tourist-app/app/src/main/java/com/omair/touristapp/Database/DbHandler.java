package com.omair.touristapp.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;

import com.omair.touristapp.Models.City;
import com.omair.touristapp.Models.Country;
import com.omair.touristapp.Models.Trip;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class DbHandler extends SQLiteOpenHelper {

    private static final int DB_VERSION = 7;
    private static final String DB_NAME = "touristsDB";


    private static final String TABLE_COUNTRIES = "countries";
    private static final String KEY_ID = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_IMAGE = "image";
    private static final String KEY_ANTHOM = "anthom_url";


    private static final String TABLE_CITIES = "cities";
    private static final String KEY_COUNTRY_ID = "country_id";
    private static final String KEY_DESCRIPTION = "description";
    private static final String KEY_DESCRIPTION_IRISH = "description_irish";
    private static final String KEY_LATITUDE = "latitude";
    private static final String KEY_LONGITUDE = "longitude";


    private static final String TABLE_TRIPS = "trips";
    private static final String KEY_LOCATION = "location";
    private static final String KEY_DATE = "date";
    private static final String KEY_TIME = "time";

    public DbHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_COUNTRIES_TABLE = "CREATE TABLE " + TABLE_COUNTRIES + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_NAME + " TEXT,"
                + KEY_ANTHOM + " TEXT,"
                + KEY_IMAGE + " BLOB" + ")";

        String CREATE_CITIES_TABLE = "CREATE TABLE " + TABLE_CITIES + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_COUNTRY_ID + " INTEGER,"
                + KEY_NAME + " TEXT,"
                + KEY_DESCRIPTION + " TEXT,"
                + KEY_DESCRIPTION_IRISH + " TEXT,"
                + KEY_LATITUDE + " DOUBLE,"
                + KEY_LONGITUDE + " DOUBLE,"
                + KEY_IMAGE + " BLOB" + ")";


        String CREATE_TRIPS_TABLE = "CREATE TABLE " + TABLE_TRIPS + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_LOCATION + " TEXT,"
                + KEY_DATE + " TEXT,"
                + KEY_TIME + " TEXT" + ")";

        db.execSQL(CREATE_COUNTRIES_TABLE);
        db.execSQL(CREATE_CITIES_TABLE);
        db.execSQL(CREATE_TRIPS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if exist
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_COUNTRIES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CITIES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRIPS);
        // Create tables again
        onCreate(db);
    }
    // **** CRUD (Create, Read, Update, Delete) Operations ***** //

    public long insertCountry(Country country) {
        //Get the Data Repository in write mode
        SQLiteDatabase db = this.getWritableDatabase();
        //Create a new map of values, where column names are the keys
        ContentValues cValues = new ContentValues();
        cValues.put(KEY_NAME, country.getName());
        cValues.put(KEY_ANTHOM, country.getAnthomUrl());
        cValues.put(KEY_IMAGE, country.convertImageToBytes());

        // Insert the new row, returning the primary key value of the new row
        long newRowId = db.insert(TABLE_COUNTRIES, null, cValues);
        db.close();
        return newRowId;
    }

    public List<Country> getCountries() {
        SQLiteDatabase db = this.getWritableDatabase();
        List<Country> userList = new ArrayList<>();
        String query = "SELECT " + KEY_ID + "," + KEY_NAME + ", " + KEY_ANTHOM + ", " + KEY_IMAGE + " FROM " + TABLE_COUNTRIES;
        Cursor cursor = db.rawQuery(query, null);
        while (cursor.moveToNext()) {
            Country country = new Country();
            country.setId(cursor.getLong(cursor.getColumnIndex(KEY_ID)));
            country.setName(cursor.getString(cursor.getColumnIndex(KEY_NAME)));
            country.setAnthomUrl(cursor.getString(cursor.getColumnIndex(KEY_ANTHOM)));
            country.setCityArrayList(getCities(country.getId()));
            country.convertBytesToBitmap(cursor.getBlob(cursor.getColumnIndex(KEY_IMAGE)));
            userList.add(country);
        }
        return userList;
    }


    public long insertCity(City city) {
        //Get the Data Repository in write mode
        SQLiteDatabase db = this.getWritableDatabase();
        //Create a new map of values, where column names are the keys
        ContentValues cValues = new ContentValues();
        cValues.put(KEY_COUNTRY_ID, city.getCountryId());
        cValues.put(KEY_NAME, city.getName());
        cValues.put(KEY_DESCRIPTION, city.getDescription());
        cValues.put(KEY_DESCRIPTION_IRISH, city.getDescriptionIrish());
        cValues.put(KEY_LATITUDE, city.getLatitude());
        cValues.put(KEY_LONGITUDE, city.getLongitude());

        cValues.put(KEY_IMAGE, city.convertImageToBytes());

        // Insert the new row, returning the primary key value of the new row
        long newRowId = db.insert(TABLE_CITIES, null, cValues);
        db.close();
        return newRowId;
    }


    public ArrayList<City> getCities(long countryId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<City> userList = new ArrayList<>();
        Cursor cursor = db.query(TABLE_CITIES, new String[]{KEY_ID, KEY_COUNTRY_ID, KEY_NAME, KEY_DESCRIPTION, KEY_DESCRIPTION_IRISH, KEY_LATITUDE, KEY_LONGITUDE, KEY_IMAGE}, KEY_COUNTRY_ID + "=?", new String[]{String.valueOf(countryId)}, null, null, null, null);
        while (cursor.moveToNext()) {
            City city = new City();
            city.setId(cursor.getLong(cursor.getColumnIndex(KEY_ID)));
            city.setCountryId(cursor.getLong(cursor.getColumnIndex(KEY_COUNTRY_ID)));
            city.setName(cursor.getString(cursor.getColumnIndex(KEY_NAME)));
            city.setDescription(cursor.getString(cursor.getColumnIndex(KEY_DESCRIPTION)));
            city.setDescriptionIrish(cursor.getString(cursor.getColumnIndex(KEY_DESCRIPTION_IRISH)));
            city.setLatitude(cursor.getDouble(cursor.getColumnIndex(KEY_LATITUDE)));
            city.setLongitude(cursor.getDouble(cursor.getColumnIndex(KEY_LONGITUDE)));
            city.convertBytesToBitmap(cursor.getBlob(cursor.getColumnIndex(KEY_IMAGE)));
            userList.add(city);
        }
        return userList;
    }

    public void flush() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_COUNTRIES, "1", null);
        db.delete(TABLE_CITIES, "1", null);
        db.delete(TABLE_TRIPS, "1", null);
        db.close();
    }

    public long insertTrip(Trip trip) {
        //Get the Data Repository in write mode
        SQLiteDatabase db = this.getWritableDatabase();
        //Create a new map of values, where column names are the keys
        ContentValues cValues = new ContentValues();
        cValues.put(KEY_LOCATION, trip.getLocation());
        cValues.put(KEY_DATE, trip.getDate());
        cValues.put(KEY_TIME, trip.getTime());

        // Insert the new row, returning the primary key value of the new row
        long newRowId = db.insert(TABLE_TRIPS, null, cValues);
        db.close();
        return newRowId;
    }

    public List<Trip> getTrips() {
        SQLiteDatabase db = this.getWritableDatabase();
        List<Trip> tripList = new ArrayList<>();
        String query = "SELECT " + KEY_ID + "," + KEY_LOCATION + ", " + KEY_DATE + ", " + KEY_TIME + " FROM " + TABLE_TRIPS;
        Cursor cursor = db.rawQuery(query, null);
        while (cursor.moveToNext()) {
            Trip trip = new Trip();
            trip.setId(cursor.getLong(cursor.getColumnIndex(KEY_ID)));
            trip.setLocation(cursor.getString(cursor.getColumnIndex(KEY_LOCATION)));
            trip.setDate(cursor.getString(cursor.getColumnIndex(KEY_DATE)));
            trip.setTime(cursor.getString(cursor.getColumnIndex(KEY_TIME)));
            tripList.add(trip);
        }
        return tripList;
    }

}
