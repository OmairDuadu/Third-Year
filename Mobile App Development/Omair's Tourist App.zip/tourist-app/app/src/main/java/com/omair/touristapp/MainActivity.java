package com.omair.touristapp;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.omair.touristapp.Controllers.BookTripActivity;
import com.omair.touristapp.Controllers.MapsActivity;
import com.omair.touristapp.Controllers.MyTripsActivity;
import com.omair.touristapp.Database.DbHandler;
import com.omair.touristapp.Models.City;
import com.omair.touristapp.Models.Country;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity:Database";
    private final DbHandler dbHandler = new DbHandler(this);


    private MediaPlayer mp;
    private Button buttonPlay;
    private Button buttonMap;
    private Spinner spinner;
    private List<Country> arrayContries;
    private ArrayAdapter<Country> adapterCountries;
    private ImageView imageViewCountry;
    private ImageView imageViewCity;
    private TextView textViewCityDescription;
    private ImageView arrowCityLeft;
    private TextView textViewCity;
    private ImageView arrowCityRight;

    private int selectedCity = 0;
    private boolean isAnthemPlaying = false;
    private boolean isTranslated = false;
    private Button buttonViewTrips;
    private Button buttonBookTrip;
    private Button buttonTranslate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dataSeeder();
        businessLogic();
        dataLoader();
        initView();
    }

    private void businessLogic() {
        mp = new MediaPlayer();
    }

    private void dataLoader() {
        arrayContries = dbHandler.getCountries();
    }

    private void initView() {
        buttonPlay = (Button) findViewById(R.id.buttonPlay);
        buttonMap = (Button) findViewById(R.id.buttonMap);
        spinner = (Spinner) findViewById(R.id.spinner);
        imageViewCountry = (ImageView) findViewById(R.id.imageViewCountry);
        imageViewCity = (ImageView) findViewById(R.id.imageViewCity);
        textViewCityDescription = (TextView) findViewById(R.id.textViewCityDescription);
        arrowCityLeft = (ImageView) findViewById(R.id.arrowCityLeft);
        textViewCity = (TextView) findViewById(R.id.textViewCity);
        arrowCityRight = (ImageView) findViewById(R.id.arrowCityRight);
        buttonViewTrips = (Button) findViewById(R.id.buttonViewTrips);
        buttonBookTrip = (Button) findViewById(R.id.buttonBookTrip);
        buttonTranslate = (Button) findViewById(R.id.buttonTranslate);
        setupListeners();
        setupSpinner();
    }

    private void setupListeners() {
        buttonPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isAnthemPlaying) {
                    mp.pause();
                    mp.reset();
                    isAnthemPlaying = false;
                } else {
                    playStream(arrayContries.get(spinner.getSelectedItemPosition()).getAnthomUrl());
                    isAnthemPlaying = true;
                }
                buttonStatus();
            }
        });
        buttonMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MapsActivity.class);
                intent.putExtra("LATITUDE", dbHandler.getCountries().get(spinner.getSelectedItemPosition()).getCityArrayList().get(selectedCity).getLatitude());
                intent.putExtra("LONGITUDE", dbHandler.getCountries().get(spinner.getSelectedItemPosition()).getCityArrayList().get(selectedCity).getLongitude());
                startActivity(intent);
            }
        });
        arrowCityLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedCity == 0) {
                    return;
                }
                selectedCity--;
                selectCity();
            }
        });
        arrowCityRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedCity == (arrayContries.get(spinner.getSelectedItemPosition()).getCityArrayList().size() - 1)) {
                    return;
                }
                selectedCity++;
                selectCity();
            }
        });
        buttonBookTrip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, BookTripActivity.class);
                startActivity(intent);
            }
        });
        buttonViewTrips.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MyTripsActivity.class);
                startActivity(intent);
            }
        });

        buttonTranslate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                City city = arrayContries.get(spinner.getSelectedItemPosition()).getCityArrayList().get(selectedCity);
                isTranslated = !isTranslated;
                if (isTranslated) {
                    textViewCityDescription.setText(city.getDescriptionIrish());
                } else {
                    textViewCityDescription.setText(city.getDescription());
                }
            }
        });
    }

    private void setupSpinner() {
        adapterCountries = new ArrayAdapter<Country>(MainActivity.this, android.R.layout.simple_dropdown_item_1line, android.R.id.text1, arrayContries);
        spinner.setAdapter(adapterCountries);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectCountry();
                selectedCity = 0;
                selectCity();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void buttonStatus() {
        if (isAnthemPlaying)
            buttonPlay.setText("Stop");
        else
            buttonPlay.setText("Play Anthem");
    }

    private void selectCountry() {
        imageViewCountry.setImageBitmap(arrayContries.get(spinner.getSelectedItemPosition()).getImage());
    }

    private void selectCity() {
        isTranslated = false;
        City city = arrayContries.get(spinner.getSelectedItemPosition()).getCityArrayList().get(selectedCity);
        textViewCity.setText(city.getName());
        textViewCityDescription.setText(city.getDescription());
        imageViewCity.setImageBitmap(city.getImage());
    }

    private void playStream(String url) {
        try {
            isAnthemPlaying = true;
            buttonStatus();

            Uri myUri = Uri.parse(url);
            mp.reset();
            mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mp.setDataSource(this, myUri);
            mp.prepare();
            mp.start();
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    isAnthemPlaying = false;
                    buttonStatus();
                }
            });
        } catch (Exception e) {
            // handle exception
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        if (mp != null)
            mp.reset();
        super.onDestroy();
    }



    private void dataSeeder() {

        dbHandler.flush();

        long countryId = dbHandler.insertCountry(new Country("Ireland",
                "http://www.nationalanthems.info/ie.mp3", BitmapFactory.decodeResource(getResources(),
                R.drawable.ireland)));
        dbHandler.insertCity(new City(countryId,
                "Dublin",
                "Dublin, capital of the Republic of Ireland, is on Ireland’s east coast at the mouth of the River Liffey. Its historic buildings include Dublin Castle, dating to the 13th century, and imposing St Patrick’s Cathedral, founded in 1191. City parks include landscaped St Stephen’s Green and huge Phoenix Park, containing Dublin Zoo. The National Museum of Ireland explores Irish heritage and culture.",
                53.3498,
                -6.2603,
                BitmapFactory.decodeResource(getResources(),
                        R.drawable.dublin),
                "Tá Baile Átha Cliath, príomhchathair Phoblacht na hÉireann, ar chósta thoir na hÉireann ag béal Abhainn na Life. I measc a fhoirgnimh stairiúla tá Caisleán Bhaile Átha Cliath, a théann siar go dtí an 13ú haois, agus Ardeaglais Naomh Pádraig, a bunaíodh i 1191. I measc na bpáirceanna cathrach tá Faiche Stiabhna tírdhreachaithe agus Páirc an Fhionnuisce ollmhór, ina bhfuil Zú Bhaile Átha Cliath. Scrúdaíonn Ard-Mhúsaem na hÉireann oidhreacht agus cultúr na hÉireann."));
        dbHandler.insertCity(new City(countryId,
                "Cork",
                "Cork is the second largest city in Ireland, located in the south-west of Ireland, in the province of Munster. Following an extension to the city's boundary in 2019, its population is c. 210,000.",
                51.8985,
                -8.4756,
                BitmapFactory.decodeResource(getResources(),
                        R.drawable.cork),
                "Is í Corcaigh an dara cathair is mó in Éirinn, atá suite in iardheisceart na hÉireann, i gCúige na Mumhan. Tar éis síneadh a chur le teorainn na cathrach in 2019, tá a daonra c. 210,000."));
        dbHandler.insertCity(new City(countryId,
                "Galway",
                "Galway, a harbour city on Ireland’s west coast, sits where the River Corrib meets the Atlantic Ocean. The city’s hub is 18th-century Eyre Square, a popular meeting spot surrounded by shops and traditional pubs that often offer live Irish folk music. Nearby, stone-clad cafes, boutiques and art galleries line the winding lanes of the Latin Quarter, which retains portions of the medieval city walls.",
                53.2707,
                -9.0568,
                BitmapFactory.decodeResource(getResources(),
                        R.drawable.galway),
                "Suíonn Gaillimh, cathair cuain ar chósta thiar na hÉireann, áit a mbuaileann Abhainn Corrib leis an Aigéan Atlantach. Is é mol na cathrach Cearnóg Eyre ón 18ú haois, áit chruinnithe a bhfuil tóir air agus é timpeallaithe ag siopaí agus tithe tábhairne traidisiúnta a chuireann ceol tíre beo Éireannach ar fáil go minic. In aice láimhe, tá caiféanna, siopaí agus dánlanna ealaíne cumhdaithe le lánaí foirceannadh na Ceathrún Laidine, a choinníonn codanna de bhallaí meánaoiseacha na cathrach."));
        dbHandler.insertCity(new City(countryId,
                "Waterford",
                "Waterford, a seaport in southeast Ireland, is the country’s oldest city. It was founded by Vikings in 914 A.D. and parts of its ancient walled core remain. Within Reginald’s Tower, a circa-1003 fortification, the Waterford Museum of Treasures displays local archaeological finds. Famed glass manufacturer Waterford Crystal began here in 1783. Today the company’s facility near the historic district offers factory tours.",
                52.2593,
                -7.1101,
                BitmapFactory.decodeResource(getResources(),
                        R.drawable.waterford),
                "Is é Port Láirge, calafort in oirdheisceart na hÉireann, an chathair is sine sa tír. Bhunaigh na Lochlannaigh é i 914 A.D. agus tá codanna dá chroí ársa ballaí fós ann. Laistigh de Thúr Reginald, daingniú circa-1003, taispeánann Músaem Seoda Phort Láirge fionnachtana seandálaíochta áitiúla. Thosaigh an monaróir gloine cáiliúil Waterford Crystal anseo i 1783. Sa lá atá inniu ann cuireann saoráid na cuideachta in aice leis an gceantar stairiúil turais monarchan ar fáil."));


        countryId = dbHandler.insertCountry(new Country("United Kingdom",
                "http://www.nationalanthems.info/gb.mp3", BitmapFactory.decodeResource(getResources(),
                R.drawable.united_kindom)));
        dbHandler.insertCity(new City(countryId, "London", "London, the capital of England and the United Kingdom, is a 21st-century city with history stretching back to Roman times. At its centre stand the imposing Houses of Parliament, the iconic ‘Big Ben’ clock tower and Westminster Abbey, site of British monarch coronations. Across the Thames River, the London Eye observation wheel provides panoramic views of the South Bank cultural complex, and the entire city.", 51.5287352, -0.3817816, BitmapFactory.decodeResource(getResources(),
                R.drawable.london), "Cathair sa 21ú haois í Londain, príomhchathair Shasana agus na Ríochta Aontaithe, le stair ag síneadh siar go dtí aimsir na Róimhe. Ag a lár tá Tithe iontacha na Parlaiminte, an túr clog íocónach ‘Big Ben’ agus Mainistir Westminster, suíomh corónaithe monarc na Breataine. Trasna Abhainn Thames, soláthraíonn roth breathnóireachta London Eye radhairc lánléargais ar choimpléasc cultúrtha an Bhruach Theas, agus ar an gcathair ar fad."));
        dbHandler.insertCity(new City(countryId, "Manchester", "Manchester is a major city in the northwest of England with a rich industrial heritage. The Castlefield conservation area’s 18th-century canal system recalls the city’s days as a textile powerhouse, and visitors can trace this history at the interactive Museum of Science & Industry. The revitalised Salford Quays dockyards now house the Daniel Libeskind-designed Imperial War Museum North and the Lowry cultural centre", 53.4723679, -2.3635462, BitmapFactory.decodeResource(getResources(),
                R.drawable.manchester)));
        dbHandler.insertCity(new City(countryId, "Brimingham", "Birmingham is a major city in England’s West Midlands region, with multiple Industrial Revolution-era landmarks that speak to its 18th-century history as a manufacturing powerhouse. It’s also home to a network of canals, many of which radiate from Sherborne Wharf and are now lined with trendy cafes and bars. In the city centre, the Birmingham Museum and Art Gallery is known for pre-Raphaelite masterpieces.", 52.477564, -2.003715, BitmapFactory.decodeResource(getResources(),
                R.drawable.bermingham), "Is cathair mhór í Manchain in iarthuaisceart Shasana a bhfuil oidhreacht thionsclaíoch shaibhir aici. Meabhraíonn córas canála 18ú haois limistéar caomhnaithe Chaisleán an Chaisleáin laethanta na cathrach mar chumhacht cumhachta teicstíle, agus is féidir le cuairteoirí an stair seo a rianú ag an Músaem Eolaíochta & Tionscail idirghníomhach. Tá Músaem Cogaidh Impiriúil Thuaidh agus ionad cultúrtha Lowry, atá deartha ag Daniel Libeskind, anois i gclós dugaí Céanna Salford athbheochanaithe."));
        dbHandler.insertCity(new City(countryId, "Liverpool", "Liverpool is a maritime city in northwest England, where the River Mersey meets the Irish Sea. A key trade and migration port from the 18th to the early 20th centuries, it's also, famously, the hometown of The Beatles. Ferries cruise the waterfront, where the iconic mercantile buildings known as the \"Three Graces\" – Royal Liver Building, Cunard Building and Port of Liverpool Building – stand on the Pier Head. ", 53.4123001, -3.0561421, BitmapFactory.decodeResource(getResources(),
                R.drawable.liverpool), "Is cathair mhuirí í Learpholl in iarthuaisceart Shasana, áit a mbuaileann Abhainn Mersey le Muir Éireann. Príomhphort trádála agus imirce ón 18ú go dtí tús an 20ú haois, is é baile dúchais na Beatles freisin. Déanann báid farantóireachta cúrsáil ar thaobh an uisce, áit a bhfuil na foirgnimh íocónacha íocónacha ar a dtugtar na \"Three Graces\" - Foirgneamh Ríoga an Ae, Foirgneamh Cunard agus Foirgneamh Port Learpholl - ar Cheann an Ché."));


        countryId = dbHandler.insertCountry(new Country("Spain",
                "http://www.nationalanthems.info/es%20short.mp3", BitmapFactory.decodeResource(getResources(),
                R.drawable.spain)));
        dbHandler.insertCity(new City(countryId, "Madrid", "Madrid, Spain's central capital, is a city of elegant boulevards and expansive, manicured parks such as the Buen Retiro. It’s renowned for its rich repositories of European art, including the Prado Museum’s works by Goya, Velázquez and other Spanish masters. The heart of old Hapsburg Madrid is the portico-lined Plaza Mayor, and nearby is the baroque Royal Palace and Armory, displaying historic weaponry.", 40.4381311, -3.819622, BitmapFactory.decodeResource(getResources(),
                R.drawable.madrid), "Is cathair le boulevards galánta agus páirceanna fairsing, lámh-mhaisithe mar an Buen Retiro í Maidrid, príomhchathair lárnach na Spáinne. Tá cáil air mar gheall ar a stórtha saibhir d’ealaín na hEorpa, lena n-áirítear saothair Mhúsaem Prado le Goya, Velázquez agus máistrí Spáinneacha eile. Is é croílár sean-Hapsburg Maidrid an Méara Plaza portico-líneáilte, agus in aice láimhe tá an Pálás Ríoga agus Armlann Bharócach, a bhfuil airm stairiúla ar taispeáint ann."));
        dbHandler.insertCity(new City(countryId, "Barcelona", "Barcelona, the cosmopolitan capital of Spain’s Catalonia region, is known for its art and architecture. The fantastical Sagrada Família church and other modernist landmarks designed by Antoni Gaudí dot the city. Museu Picasso and Fundació Joan Miró feature modern art by their namesakes. City history museum MUHBA, includes several Roman archaeological sites.", 41.3948976, 2.0787276, BitmapFactory.decodeResource(getResources(),
                R.drawable.barcelona), "Tá cáil ar Barcelona, \u200B\u200Bpríomhchathair chosmopolitan réigiún na Catalóine sa Spáinn, mar gheall ar a healaín agus a hailtireacht. Tá séipéal iontach Sagrada Família agus sainchomharthaí nua-aoiseacha eile deartha ag Antoni Gaudí sa chathair. Tá ealaín nua-aimseartha ag Museu Picasso agus Fundació Joan Miró de réir a n-ainmneacha. Cuimsíonn músaem stair na cathrach MUHBA, roinnt suíomhanna seandálaíochta Rómhánacha."));
        dbHandler.insertCity(new City(countryId, "Cordoba", "Córdoba is a city in the southern Spanish region of Andalusia, and the capital of the province of Córdoba. It was an important Roman city and a major Islamic center in the Middle Ages. It’s best known for La Mezquita, an immense mosque dating from 784 A.D., featuring a columned prayer hall and older Byzantine mosaics. After it became a Catholic church in 1236, a Renaissance-style nave was added in the 17th century. ", 37.8916069, -4.8195048, BitmapFactory.decodeResource(getResources(),
                R.drawable.cordoba), "Cathair i réigiún theas na Spáinne in Andalucía is ea Córdoba, agus príomhchathair chúige Córdoba. Cathair thábhachtach Rómhánach a bhí inti agus lárionad mór Ioslamach sa Mheán-Aois. Is fearr aithne air do La Mezquita, mosc ollmhór a théann siar ó 784 A.D., ina bhfuil halla urnaí colún agus mósáicí Byzantine níos sine. Tar éis di a bheith ina heaglais Chaitliceach i 1236, cuireadh corp i stíl na hAthbheochana sa 17ú haois."));
        dbHandler.insertCity(new City(countryId, "Toledo", "Toledo is an ancient city set on a hill above the plains of Castilla-La Mancha in central Spain. The capital of the region, it’s known for the medieval Arab, Jewish and Christian monuments in its walled old city. It was also the former home of Mannerist painter El Greco. The Moorish Bisagra Gate and the Sol Gate, in Mudéjar style, open into the old quarter, where the Plaza de Zocodover is a lively meeting place.", 39.86232, -4.0694702, BitmapFactory.decodeResource(getResources(),
                R.drawable.toledo), "Is cathair ársa í Toledo atá suite ar chnoc os cionn machairí Castilla-La Mancha i lár na Spáinne. Príomhchathair an réigiúin, is eol dó na séadchomharthaí meánaoiseacha Arabacha, Giúdacha agus Críostaí ina seanchathair múrtha. Ba iar-bhaile an phéintéara Mannerist El Greco é freisin. Osclaítear Geata Bisagra Moorish agus Geata Sol, i stíl Mudéjar, isteach sa sean ráithe, áit a bhfuil an Plaza de Zocodover ina áit chruinnithe bríomhar."));


        countryId = dbHandler.insertCountry(new Country("Japan",
                "http://www.nationalanthems.info/jp.mp3", BitmapFactory.decodeResource(getResources(),
                R.drawable.japan)));
        dbHandler.insertCity(new City(countryId, "Tokyo", "Tokyo, Japan’s busy capital, mixes the ultramodern and the traditional, from neon-lit skyscrapers to historic temples. The opulent Meiji Shinto Shrine is known for its towering gate and surrounding woods. The Imperial Palace sits amid large public gardens. The city's many museums offer exhibits ranging from classical art (in the Tokyo National Museum) to a reconstructed kabuki theater (in the Edo-Tokyo Museum).", 35.6684415, 139.6007818, BitmapFactory.decodeResource(getResources(),
                R.drawable.tokyo), "Meascann Tóiceo, príomhchathair ghnóthach na Seapáine, an ultramodern agus an traidisiúnta, ó skyscrapers neon-lit go temples stairiúla. Tá Scrín Meiji Shinto opulentach ar eolas mar gheall ar a gheata ard agus a choillte máguaird. Suíonn an Pálás Impiriúil i measc gairdíní móra poiblí. Cuireann go leor músaem na cathrach taispeántais ar fáil ó ealaín chlasaiceach (in Ard-Mhúsaem Tóiceo) go dtí amharclann kabuki atógtha (i Músaem Edo-Tóiceo)."));
        dbHandler.insertCity(new City(countryId, "Osaka", "Osaka is a large port city and commercial center on the Japanese island of Honshu. It's known for its modern architecture, nightlife and hearty street food. The 16th-century shogunate Osaka Castle, which has undergone several restorations, is its main historical landmark. It's surrounded by a moat and park with plum, peach and cherry-blossom trees. Sumiyoshi-taisha is among Japan’s oldest Shinto shrines.", 34.6777645, 135.4160242, BitmapFactory.decodeResource(getResources(),
                R.drawable.osaka), "Is cathair mhór calafoirt agus ionad tráchtála é Osaka ar oileán Honshu na Seapáine. Tá sé ar eolas mar gheall ar a ailtireacht nua-aimseartha, a shaol oíche agus a bhia sráide croíúil. Is é Caisleán Osaka suarach an 16ú haois, a ndearnadh roinnt athchóirithe air, a phríomhchomhartha stairiúil. Tá móta agus páirc timpeall air le crainn pluma, péitseog agus bláthach silíní. Tá Sumiyoshi-taisha i measc na scrínte Shinto is sine sa tSeapáin."));
        dbHandler.insertCity(new City(countryId, "Kyoto", "Kyoto, once the capital of Japan, is a city on the island of Honshu. It's famous for its numerous classical Buddhist temples, as well as gardens, imperial palaces, Shinto shrines and traditional wooden houses. It’s also known for formal traditions such as kaiseki dining, consisting of multiple courses of precise dishes, and geisha, female entertainers often found in the Gion district. ", 35.0984796, 135.4386811, BitmapFactory.decodeResource(getResources(),
                R.drawable.kyoto), "Cathair ar oileán Honshu is ea Kyoto, a bhí mar phríomhchathair na Seapáine uair. Tá clú air mar gheall ar a theampaill Bhúdaíocha iomadúla, chomh maith le gairdíní, palaces impiriúla, scrínte Shinto agus tithe adhmaid traidisiúnta. Tá sé ar eolas freisin mar gheall ar thraidisiúin fhoirmiúla ar nós bia kaiseki, ina bhfuil iliomad cúrsaí miasa beachta, agus geisha, siamsóirí mná a fhaightear go minic i gceantar Gion."));
        dbHandler.insertCity(new City(countryId, "Nagoya", "Nagoya, capital of Japan’s Aichi Prefecture, is a manufacturing and shipping hub in central Honshu. The city’s Naka ward is home to museums and pachinko (gambling machine) parlors. Naka also includes the Sakae entertainment district, with attractions like the Sky-Boat Ferris wheel, which is attached to a mall. In northern Naka is Nagoya Castle, a partly reconstructed 1612 royal home displaying Edo-era artifacts", 35.1473114, 136.7862176, BitmapFactory.decodeResource(getResources(),
                R.drawable.nagoya), "Is mol déantúsaíochta agus seolta é Nagoya, príomhchathair Aichi Prefecture na Seapáine, i lár Honshu. Tá músaem agus parlors pachinko (meaisín cearrbhachais) i mbarda Naka na cathrach. Cuimsíonn Naka ceantar siamsaíochta Sakae freisin, le nithe cosúil le roth Ferris Sky-Boat, atá ceangailte le Meall. I dtuaisceart Naka tá Caisleán Nagoya, teach ríoga 1612 atógtha go páirteach ag taispeáint déantáin Edo-era"));


        countryId = dbHandler.insertCountry(new Country("Pakistan",
                "http://www.nationalanthems.info/pk.mp3", BitmapFactory.decodeResource(getResources(),
                R.drawable.pakistan)));
        dbHandler.insertCity(new City(countryId, "Karachi", "Karachi is the capital of the Pakistani province of Sindh. It is the largest city in Pakistan and the twelfth largest city in the world. Ranked as a beta-global city, the city is Pakistan's premier industrial and financial centre, with an estimated GDP of $114 billion as of 2014. ", 25.1933895, 66.5949757, BitmapFactory.decodeResource(getResources(),
                R.drawable.karachi), "Is é Karachi príomhchathair chúige Phacastáin Sindh. Is í an chathair is mó sa Phacastáin í agus an dara cathair déag is mó ar domhan. Rangaítear í mar chathair béite-dhomhanda, is í an chathair príomhionad tionsclaíoch agus airgeadais na Pacastáine, le OTI measta de $ 114 billiún ó 2014."));
        dbHandler.insertCity(new City(countryId, "Islamabad", "Islamabad is the capital city of Pakistan, and is federally administered as part of the Islamabad Capital Territory. Islamabad is the ninth largest city in Pakistan, while the larger Islamabad–Rawalpindi metropolitan area is the country's fourth largest with a population of about 3.1 million. ", 33.6163232, 72.9460219, BitmapFactory.decodeResource(getResources(),
                R.drawable.islamabad), "Is í Islamabad príomhchathair na Pacastáine, agus déantar í a riaradh go cónaidhme mar chuid de Chríoch Chaipitil Islamabad. Is é Islamabad an naoú cathair is mó sa Phacastáin, agus is í an limistéar cathrach is mó Islamabad-Rawalpindi an ceathrú cathair is mó sa tír le daonra de thart ar 3.1 milliún."));
        dbHandler.insertCity(new City(countryId, "Lahore", "Lahore is the capital of the Pakistani province of Punjab and is the country's 2nd largest city after Karachi, as well as the 26th largest city in the world. Lahore is one of Pakistan's wealthiest cities with an estimated GDP of $65.14 billion as of 2017", 31.4832209, 74.0541951, BitmapFactory.decodeResource(getResources(),
                R.drawable.lahore), "Is í Lahore príomhchathair chúige Pacastáine Punjab agus is í an dara cathair is mó sa tír i ndiaidh Karachi, chomh maith leis an 26ú cathair is mó ar domhan. Tá Lahore ar cheann de na cathracha is saibhre sa Phacastáin le OTI measta de $ 65.14 billiún amhail ó 2017"));
        dbHandler.insertCity(new City(countryId, "Multan", "Multan is a city and capital of Multan Division located in Punjab, Pakistan. Located on the bank of the Chenab River, Multan is Pakistan's 7th largest city and is the major cultural and economic centre of southern Punjab. Multan's history stretches deep into antiquity. ", 30.1814786, 71.3345718, BitmapFactory.decodeResource(getResources(),
                R.drawable.multan), "Is cathair agus príomhchathair de chuid Rannán Multan é Multan atá lonnaithe i Punjab, sa Phacastáin. Suite ar bhruach Abhainn Chenab, is í Multan an 7ú cathair is mó sa Phacastáin agus is í an príomhionad cultúrtha agus eacnamaíoch i ndeisceart Punjab. Síneann stair Multan go domhain i seandacht."));

    }

}