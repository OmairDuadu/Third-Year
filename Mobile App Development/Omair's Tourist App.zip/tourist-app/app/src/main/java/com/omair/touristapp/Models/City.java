package com.omair.touristapp.Models;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

public class City {

    private long id;
    private long countryId;
    private String name;
    private String description;
    private Double latitude;
    private Double longitude;
    private Bitmap image;
    private String descriptionIrish;

    public City() {
    }

    public City(long countryId, String name, String description, Double latitude, Double longitude) {
        this.countryId = countryId;
        this.name = name;
        this.description = description;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public City(long countryId, String name, String description, Double latitude, Double longitude, Bitmap image) {
        this.countryId = countryId;
        this.name = name;
        this.description = description;
        this.latitude = latitude;
        this.longitude = longitude;
        this.image = image;
    }

    public City(long countryId, String name, String description, Double latitude, Double longitude, Bitmap image, String descriptionIrish) {
        this.countryId = countryId;
        this.name = name;
        this.description = description;
        this.latitude = latitude;
        this.longitude = longitude;
        this.image = image;
        this.descriptionIrish = descriptionIrish;
    }

    public String getDescriptionIrish() {
        return descriptionIrish;
    }

    public void setDescriptionIrish(String descriptionIrish) {
        this.descriptionIrish = descriptionIrish;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getCountryId() {
        return countryId;
    }

    public void setCountryId(long countryId) {
        this.countryId = countryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Bitmap getImage() {
        return image;
    }

    public void setImage(Bitmap image) {
        this.image = image;
    }

    public byte[] convertImageToBytes() {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        getImage().compress(Bitmap.CompressFormat.JPEG, 100, stream);
        return stream.toByteArray();
    }


    public void convertBytesToBitmap(byte[] image) {
        ByteArrayInputStream imageStream = new ByteArrayInputStream(image);
        Bitmap theImage = BitmapFactory.decodeStream(imageStream);
        setImage(theImage);
    }

    @Override
    public String toString() {
        return getName();
    }
}
