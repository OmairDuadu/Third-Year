package com.omair.touristapp.Controllers;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.omair.touristapp.Database.DbHandler;
import com.omair.touristapp.Models.Trip;
import com.omair.touristapp.R;

public class BookTripActivity extends AppCompatActivity {

    private final DbHandler dbHandler = new DbHandler(this);

    private EditText edittextAddress;
    private EditText edittextDate;
    private EditText edittextTime;
    private Button buttonBook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_trip);
        initView();
    }

    private void initView() {
        edittextAddress = (EditText) findViewById(R.id.edittextAddress);
        edittextDate = (EditText) findViewById(R.id.edittextDate);
        edittextTime = (EditText) findViewById(R.id.edittextTime);
        buttonBook = (Button) findViewById(R.id.buttonBook);
        buttonBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edittextAddress.getText().toString().trim().equals("")) {
                    Toast.makeText(BookTripActivity.this, "Please enter location", Toast.LENGTH_SHORT).show();
                    return;
                } else if (edittextDate.getText().toString().trim().equals("")) {
                    Toast.makeText(BookTripActivity.this, "Please enter date", Toast.LENGTH_SHORT).show();
                    return;
                } else if (edittextTime.getText().toString().trim().equals("")) {
                    Toast.makeText(BookTripActivity.this, "Please enter time", Toast.LENGTH_SHORT).show();
                    return;
                }
                saveTrip();
            }
        });
    }

    private void saveTrip() {
        dbHandler.insertTrip(new Trip(edittextAddress.getText().toString().trim(),
                edittextDate.getText().toString().trim(),
                edittextTime.getText().toString().trim()));
        Toast.makeText(this, "Trip booked successfully", Toast.LENGTH_SHORT).show();
        finish();
    }
}