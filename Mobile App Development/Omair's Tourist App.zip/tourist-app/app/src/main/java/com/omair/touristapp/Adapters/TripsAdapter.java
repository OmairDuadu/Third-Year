package com.omair.touristapp.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.omair.touristapp.Models.Trip;
import com.omair.touristapp.R;

import java.util.List;

public class TripsAdapter extends RecyclerView.Adapter<TripsAdapter.TripView> {

    private Context context;
    private List<Trip> list;

    public TripsAdapter(Context context, List<Trip> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public TripView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new TripView(LayoutInflater.from(context).inflate(R.layout.layout_trip_view, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull TripView holder, int position) {
        holder.bind(position);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class TripView extends RecyclerView.ViewHolder {

        private TextView textViewLocation;
        private TextView textViewDate;
        private TextView textViewTime;

        public TripView(@NonNull View itemView) {
            super(itemView);

            textViewLocation = (TextView) itemView.findViewById(R.id.textViewLocation);
            textViewDate = (TextView) itemView.findViewById(R.id.textViewDate);
            textViewTime = (TextView) itemView.findViewById(R.id.textViewTime);

        }

        public void bind(int position) {
            Trip trip = list.get(position);
            textViewLocation.setText(trip.getLocation());
            textViewDate.setText(trip.getDate());
            textViewTime.setText(trip.getTime());
        }
    }
}
